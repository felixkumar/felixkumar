# Copyright 2018 Tecnativa - Sergio Teruel
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
{
    "name": "Sale Report Margin",
    "version": "12.0.1.0.0",
    "author": "Tecnativa,"
              "Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/sale-reporting",
    "development_status": "Production/Stable",
    "maintainers": ["sergio-teruel"],
    "category": "Sales",
    "license": "AGPL-3",
    "depends": [
        "sale_margin",
    ],
    "installable": True,
}
